﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADAGE_NEW.Lib
{
    public class Room
    {
        //Draw Stairs
        public void stairs(Graphics g)
        {
            // Create pen.
            Pen pen = new Pen(Color.Black, 3);

            // Create array of points that define lines to draw.
            Point[] points =
                     {
                 new Point(20,  175), new Point(80, 175),
                 new Point(80, 280), new Point(240, 280)
             };

            //Draw lines to screen.
            g.DrawLines(pen, points);
        }

        public void UtilityCupboard(Graphics g)
        {
            // Create pen.
            Pen pen = new Pen(Color.Black, 3);

            // Create array of points that define lines to draw.
            Point[] points =
                     {
                 new Point(200,  280), new Point(200, 355)
             };

            //Draw lines to screen.
            g.DrawLines(pen, points);
        }

        public void Toilet(Graphics g)
        {
            // Create pen.
            Pen pen = new Pen(Color.Black, 3);

            // Create array of points that define lines to draw.
            Point[] points =
                     {
                 new Point(140,  280), new Point(140, 355)
             };

            //Draw lines to screen.
            g.DrawLines(pen, points);
        }


    }
}
