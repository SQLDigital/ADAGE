﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADAGE_NEW.Lib
{
    public class Floor
    {
        public void floor(int horizontal_position, int vertical_position, float width, float height, Graphics g)
        {
            Pen blackPen = new Pen(Color.Black, 3);

            // Draw rectangle to screen.
            g.DrawRectangle(blackPen, horizontal_position, vertical_position, width, height);
        }

    }
}
