﻿using ADAGE_NEW.Lib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADAGE_NEW
{
    public partial class Form1 : Form
    {
        Floor floor = new Floor();
        Room room = new Room();
        Graphics g = null;
        int no_of_floor,no_of_room;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                loadParameters(dataGridView1);
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
            }
        }

        private void loadParameters(DataGridView dataGridView)
        {
            dataGridView.Rows.Add(3);
            int x = dataGridView.Rows.Count - 1;

            dataGridView.Rows[0].Cells[0].Value = "Number of Floor";
            dataGridView.Rows[1].Cells[0].Value = "Number of Room";
            dataGridView.Rows[2].Cells[0].Value = "Number of Bathroom";

            //pnlSheet.Visible = false;
        }




        private void Room()
        {
            Pen blackPen = new Pen(Color.Red, 1);

            // Create location and size of rectangle.
            int x = 13;
            int y = 14;
            int width = 244;
            int height = 350;

            // Draw rectangle to screen.
            //pnlSheet.CreateGraphics()
            g.DrawRectangle(blackPen,x,y,width,height);
            //e.Graphics.DrawRectangle(blackPen, x, y, width, height);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                no_of_floor = Convert.ToInt32(dataGridView1.Rows[0].Cells[1].Value);
                no_of_room = Convert.ToInt32(dataGridView1.Rows[0].Cells[1].Value);


                pnlSheet.Refresh();
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message.ToString());
            }
            
        }

        private void pnlSheet_Paint(object sender, PaintEventArgs e)
        {
            GraphicsUnit unit = GraphicsUnit.Millimeter;
            
            //g.PageUnit= unit;
            if (no_of_floor > 0 && !string.IsNullOrWhiteSpace(no_of_floor.ToString()))
            {
                int x = 20;
                int y = 5;
                for (int i = 0; i < no_of_floor; i++)
                {
                    g = pnlSheet.CreateGraphics();
                    floor.floor(x, y, 220, 350, g);
                    if (i == 0)
                    {
                        room.stairs(g);
                        room.UtilityCupboard(g);
                        room.Toilet(g);
                    }

                    x += 295;
                }
            }
        }

    }
}
